import React from "react";

const HotSale = () => {
  return (
    <div>
      <h1>Hot Sale Component</h1>
    </div>
  );
};

export default HotSale;
