import React from "react";

const NewSale = () => {
  return (
    <div>
      <h1>New Sale Component</h1>
    </div>
  );
};

export default NewSale;
