import React from "react";

const ComingSoon = () => {
  return (
    <div className="w-screen h-96 flex items-center justify-center bg-white text-black">
      <h1 className="text-4xl md:text-6xl font-bold">Coming Soon</h1>
    </div>
  );
};

export default ComingSoon;
